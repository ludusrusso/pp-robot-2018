int8 linear_x
int8 angular_z
bool shoot
